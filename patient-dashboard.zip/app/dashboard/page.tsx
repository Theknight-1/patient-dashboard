import type { Metadata } from "next"
import Link from "next/link"
import { getSession } from "@/lib/auth"
import { getWeightEntries } from "@/actions/weight-actions"
import { getShipments, addMockShipments } from "@/actions/shipment-actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { ArrowRight, Package, TrendingDown } from "lucide-react"

export const metadata: Metadata = {
  title: "Dashboard | Acme Patient Dashboard",
  description: "Your Acme patient dashboard overview",
}

export default async function DashboardPage() {
  const user = await getSession()
  const weightEntries = await getWeightEntries()
  const shipments = await getShipments()

  // Format weight data for chart
  const weightData = weightEntries.map((entry) => ({
    date: new Date(entry.date).toLocaleDateString(),
    weight: entry.weight,
  }))

  // Get latest weight
  const latestWeight = weightEntries.length > 0 ? weightEntries[weightEntries.length - 1].weight : null

  // Get next shipment
  const nextShipment = shipments.find((shipment) => shipment.status === "processing" || shipment.status === "shipped")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <form action={addMockShipments}>
          <Button variant="outline" size="sm">
            Add Demo Data
          </Button>
        </form>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Current Weight Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Weight</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{latestWeight ? `${latestWeight} kg` : "No data"}</div>
            <p className="text-xs text-muted-foreground">
              {weightEntries.length > 1
                ? `${(latestWeight! - weightEntries[0].weight).toFixed(1)} kg since start`
                : "Add weight entries to track progress"}
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/dashboard/weight" className="text-sm text-primary hover:underline">
              View weight history
            </Link>
          </CardFooter>
        </Card>

        {/* Next Shipment Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Shipment</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {nextShipment ? nextShipment.medicationType : "No upcoming shipments"}
            </div>
            <p className="text-xs text-muted-foreground">
              {nextShipment ? `Status: ${nextShipment.status}` : "Check back later for updates"}
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/dashboard/shipments" className="text-sm text-primary hover:underline">
              View all shipments
            </Link>
          </CardFooter>
        </Card>

        {/* Quick Actions Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start" asChild>
              <Link href="/dashboard/weight">
                <TrendingDown className="mr-2 h-4 w-4" />
                Log Weight
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start" asChild>
              <Link href="/dashboard/shipments">
                <Package className="mr-2 h-4 w-4" />
                Track Shipments
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Weight Progress Chart */}
      <Card className="col-span-3">
        <CardHeader>
          <CardTitle>Weight Progress</CardTitle>
          <CardDescription>Your weight tracking over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {weightData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="weight" stroke="#8884d8" activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center">
                <p className="text-muted-foreground">No weight data available</p>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="ml-auto" asChild>
            <Link href="/dashboard/weight">
              View Details
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
